-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2021 at 07:52 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tv_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `userName`, `password`, `email`, `full_name`, `user_role`, `created_at`, `updated_at`) VALUES
(1, 'Abdur Rahman', '$2y$10$8GflDYHqbfJT01S/eQHHm.qClyBgzFqzk/4uVc86OwQ.J/z2CFnEy', 'admin@admins', 'ProRahman', 'super_admin', '2021-06-06 05:37:01', '2021-06-06 05:37:01');

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admob_inter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admob_native` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admob_banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admob_reward` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_inter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_native` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_reward` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startup_inter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startup_banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industrial_interval` int(11) DEFAULT NULL,
  `native_ads` int(11) DEFAULT NULL,
  `ad_types` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`id`, `admob_inter`, `admob_native`, `admob_banner`, `admob_reward`, `fb_inter`, `fb_native`, `fb_banner`, `fb_reward`, `startup_inter`, `startup_banner`, `industrial_interval`, `native_ads`, `ad_types`, `created_at`, `updated_at`) VALUES
(1, 'a', 'b', 'c', 'd', 'e', 'f', 'gsde', 'h', 'i', 'j', 3, 3, '3', NULL, '2021-07-24 22:50:53');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `prdct_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prdct_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prdct_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `prdct_name`, `prdct_price`, `prdct_key`, `created_at`, `updated_at`) VALUES
(3, 'Nice One', '300', 'qwedswertghbvcxcvnkio9876543', '2021-08-02 23:07:52', '2021-08-02 23:07:52'),
(4, 'advance', '2344', 'qwedswertghbvcxcvnki', '2021-08-02 23:09:02', '2021-08-02 23:41:04');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`, `country_image`, `created_at`, `updated_at`) VALUES
(4, 'Bangladesh1', '1626507831.jpg', '2021-07-17 01:43:51', '2021-07-24 22:14:28'),
(6, 'Iran', '1627366296.png', '2021-07-27 00:11:37', '2021-07-27 00:11:37');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `android_version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `device_name`, `android_version`, `message`, `email`, `created_at`, `updated_at`) VALUES
(1, 'samsung', 'version1', 'dekhajak ki hoi', 'prohor@gmail.com', '2021-08-01 04:30:14', '2021-08-01 04:30:14'),
(3, 'samsung s9', 'version2', 'Wow Nice', 'shobuj@gmail.com', '2021-08-01 04:30:50', '2021-08-01 04:30:50');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `content_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cntry_id` int(11) NOT NULL,
  `view_count` int(11) DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watch_ads` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `ratings` double DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `image`, `banner_image`, `cat_id`, `content_type`, `url`, `url_type`, `cntry_id`, `view_count`, `token`, `token_type`, `user_agent`, `agent_type`, `watch_ads`, `subscription`, `content_id`, `ratings`, `description`, `created_at`, `updated_at`) VALUES
(23, 'dbug', '1627547899.jpg', '693236255.jpg', 2, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '1', 6, 9, NULL, NULL, NULL, NULL, NULL, 'paid', 0, 10, NULL, '2021-07-29 02:38:19', '2021-08-02 03:23:49'),
(24, 'Aupi Karim', '1627809107.jpg', '1839376375.jpg', 2, 'video', 'https://www.google.com/', '1', 4, 10, NULL, NULL, NULL, NULL, NULL, 'paid', 3, 4.7, NULL, '2021-08-01 03:11:47', '2021-08-03 01:26:47'),
(26, 'new channel240', '1627972023.jpg', '297391159.jpg', 2, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '1', 6, NULL, NULL, NULL, NULL, NULL, NULL, 'paid', 3, NULL, NULL, '2021-08-03 00:27:03', '2021-08-03 01:00:47'),
(27, 'আব্দুর রাহমান', '1627975647.png', '151839784.png', 2, 'video', 'https://www.google.com/', '1', 6, 8, NULL, NULL, NULL, NULL, NULL, 'free', 3, NULL, NULL, '2021-08-03 01:27:28', '2021-08-03 01:27:46'),
(28, 'Mredul Kanti', '1629009103.jpg', '1484790095.jpg', 3, 'channel', 'jeans', '3', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-08-15 00:31:43', '2021-08-15 00:31:43'),
(29, 'kiya', '1629013033.jpg', '1014538768.jpg', 2, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '3', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-08-15 01:37:13', '2021-08-15 01:37:13'),
(30, 'dbug Station', '1629277561.jpg', '1611834473.jpg', 2, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '3', 4, NULL, NULL, NULL, NULL, NULL, 'paid', 'paid', 4, NULL, NULL, '2021-08-18 03:06:01', '2021-08-18 03:06:01'),
(31, 'prohor Coffee', '1629277667.jpg', '809699969.jpg', 3, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '3', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-08-18 03:07:47', '2021-08-18 03:07:47'),
(32, 'আব্দুর রাহমান', '1629277755.jpg', '1028577820.jpg', 2, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '4', 4, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, 0, NULL, NULL, '2021-08-18 03:09:15', '2021-08-18 03:09:15'),
(33, 'SAKHAWAT HOSSAIN', '1629277898.jpg', '1355270396.jpg', 3, 'channel', 'https://www.google.com/', '4', 6, NULL, NULL, NULL, NULL, NULL, 'paid', NULL, 4, NULL, NULL, '2021-08-18 03:11:38', '2021-08-18 03:11:38'),
(34, 'SAKHAWAT HOSSAIN', '1629278082.jpg', '965499968.jpg', 2, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '5', 6, NULL, NULL, NULL, NULL, NULL, NULL, 'paid', 4, NULL, NULL, '2021-08-18 03:14:42', '2021-08-18 03:14:42'),
(35, 'prohor', '1629278137.png', '351611611.jpg', 3, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '3', 6, NULL, NULL, NULL, NULL, NULL, 'yes', 'paid', 3, NULL, NULL, '2021-08-18 03:15:37', '2021-08-18 03:30:12'),
(37, 'prohor Khamkheyali', '1629278719.jpg', '1638532248.jpg', 3, 'channel', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '5', 6, NULL, NULL, NULL, NULL, NULL, NULL, 'paid', 3, NULL, NULL, '2021-08-18 03:25:19', '2021-08-18 03:29:20'),
(38, 'new content', '1629279818.jpg', '1555825388.jpg', 2, 'video', 'https://www.youtube.com/watch?v=4iRnfJ13Ofs', '3', 4, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, NULL, NULL, NULL, '2021-08-18 03:43:38', '2021-08-18 03:43:38');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(60, '2021_04_20_051617_create_regusers_table', 3),
(64, '2014_10_12_000000_create_users_table', 6),
(67, '2021_03_21_120852_create_admins_table', 6),
(68, '2021_05_27_075818_create_sliders_table', 7),
(69, '2021_06_21_062028_create_advertisements_table', 7),
(80, '2021_06_21_101831_create_settings_table', 8),
(81, '2021_06_24_112246_create_tokens_table', 8),
(82, '2021_06_29_060235_create_notifications_table', 8),
(83, '2021_07_14_064610_create_tv_categories_table', 8),
(84, '2021_07_14_064710_create_video_categories_table', 8),
(87, '2021_07_14_074503_create_countries_table', 8),
(88, '2021_07_14_080503_create_url_types_table', 8),
(89, '2021_07_14_090933_create_user_agent_types_table', 8),
(90, '2021_07_15_120252_create_token_types_table', 9),
(91, '2021_07_28_061246_create_items_table', 10),
(92, '2021_08_01_101010_create_feedback_table', 11),
(93, '2021_08_02_052114_create_ratings_table', 12),
(94, '2021_08_02_063812_create_reports_table', 13),
(95, '2021_08_03_042653_create_contents_table', 14);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `message`, `url`, `image_url`, `created_at`, `updated_at`) VALUES
(1, 'Hair Cut', 'asdgfhjhhhgf', 'https://www.google.com/', 'https://i.pinimg.com/736x/5c/a9/6f/5ca96fe550aab0f2cc2768d3dee9417d.jpg', '2021-07-25 04:46:15', '2021-07-25 04:46:15');

-- --------------------------------------------------------

--
-- Table structure for table `regusers`
--

CREATE TABLE `regusers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirm_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `item_id`, `message`, `created_at`, `updated_at`) VALUES
(1, 21, 'simple text', '2021-08-02 05:11:04', '2021-08-02 05:11:04');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `app_fcm_key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `app_version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ggl_ply_lcns_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ggl_product_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `privacy_policy` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `app_fcm_key`, `api_key`, `app_version`, `ggl_ply_lcns_key`, `ggl_product_key`, `privacy_policy`, `created_at`, `updated_at`) VALUES
(1, 'zxecr6796v87bu9honk/ljbkhvjgchfvh bhjknmihouigyuftr', 'fchgjvhiooijoj', 'bvgft', 'dfghjkjbvbn', '1asgdggfedw5EgrFdwerght', 'aswqswawqsaewsdewqasw', NULL, '2021-08-01 02:12:30');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slider_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `sname`, `image`, `slider_type`, `item_id`, `created_at`, `updated_at`) VALUES
(48, 'New Slide', '1629610709.jpg', 'video', 24, '2021-08-21 23:38:29', '2021-08-21 23:38:29'),
(49, 'Slide02', '1629610756.jpg', 'tvChannel', 26, '2021-08-21 23:39:16', '2021-08-21 23:39:16');

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `device_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `token_types`
--

CREATE TABLE `token_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `token_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_type_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `token_types`
--

INSERT INTO `token_types` (`id`, `token_name`, `token_type_value`, `created_at`, `updated_at`) VALUES
(1, 'json', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tv_categories`
--

CREATE TABLE `tv_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tv_cat_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tv_cat_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tv_categories`
--

INSERT INTO `tv_categories` (`id`, `tv_cat_name`, `tv_cat_image`, `created_at`, `updated_at`) VALUES
(2, 'Entertainment', '1626589082.jpg', '2021-07-16 03:07:06', '2021-07-24 12:10:41'),
(3, 'Enterta', '1627150251.png', '2021-07-16 03:19:57', '2021-07-24 12:11:00');

-- --------------------------------------------------------

--
-- Table structure for table `url_types`
--

CREATE TABLE `url_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_typ_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `url_types`
--

INSERT INTO `url_types` (`id`, `type_name`, `url_typ_value`, `created_at`, `updated_at`) VALUES
(2, 'hls', '1', NULL, NULL),
(3, 'youtube', '2', NULL, NULL),
(4, 'rtmp', '3', NULL, NULL),
(5, 'rtsp', '4', NULL, NULL),
(6, 'ts', '5', NULL, NULL),
(7, 'embed', '6', NULL, NULL),
(8, 'daily motion', '7', NULL, NULL),
(9, 'vimeo', '8', NULL, NULL),
(10, 'others', '9', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_agent_types`
--

CREATE TABLE `user_agent_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `agent_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agnt_type_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_agent_types`
--

INSERT INTO `user_agent_types` (`id`, `agent_name`, `agnt_type_value`, `created_at`, `updated_at`) VALUES
(1, 'json', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `video_categories`
--

CREATE TABLE `video_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `video_cat_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_cat_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `video_categories`
--

INSERT INTO `video_categories` (`id`, `video_cat_name`, `video_cat_image`, `created_at`, `updated_at`) VALUES
(2, 'videoAmzad', '1627150329.jpg', '2021-07-24 04:33:18', '2021-07-24 12:12:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `feedback_email_unique` (`email`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regusers`
--
ALTER TABLE `regusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token_types`
--
ALTER TABLE `token_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tv_categories`
--
ALTER TABLE `tv_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `url_types`
--
ALTER TABLE `url_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_agent_types`
--
ALTER TABLE `user_agent_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_categories`
--
ALTER TABLE `video_categories`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `regusers`
--
ALTER TABLE `regusers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `token_types`
--
ALTER TABLE `token_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tv_categories`
--
ALTER TABLE `tv_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `url_types`
--
ALTER TABLE `url_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_agent_types`
--
ALTER TABLE `user_agent_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `video_categories`
--
ALTER TABLE `video_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
