<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Advertisement;
use Session;

class AdvertisementController extends Controller
{
    public function index(){
        session::put('page','ads');
        return view('admin.advertisement')->with('ads',Advertisement::first());
    }

    //Update advertise Details
    public function update(Request $request){
        $ads = Advertisement::first();

        $ads->admob_inter = $request->input('admob_inter');
        $ads->admob_native = $request->input('admob_native');
        $ads->admob_banner = $request->input('admob_banner');
        $ads->admob_reward = $request->input('admob_reward');
        $ads->fb_inter = $request->input('fb_inter');
        $ads->fb_native = $request->input('fb_native');
        $ads->fb_banner = $request->input('fb_banner');
        $ads->fb_reward = $request->input('fb_reward');
        $ads->startup_inter = $request->input('startup_inter');
        
        $ads->startup_banner = $request->input('startup_banner');
        
        $ads->industrial_interval = $request->input('industrial_interval');
        $ads->native_ads = $request->input('native_ads');
        $ads->ad_types = $request->input('ads_type');

        // dd($ads);
        $ads->save();
        return redirect()->back()->with('message', 'Details Updated!');
    }
}
