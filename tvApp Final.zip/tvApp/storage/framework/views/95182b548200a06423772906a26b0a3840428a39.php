
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Category</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/Aindex')); ?>"> Administrator </a></li>
            <li class="breadcrumb-item active">Edit Admin</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
    <!-- /.content-header -->
      <!-- Main content -->
      <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit Admin</h3>
              </div>
              <br>
               <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
              <!-- /.card-header -->
              <!-- form start -->
              <form name="adminForm" id="adminForm"   action="<?php echo e(url('admin/Aupdate/'.$admindata->id)); ?>"   method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="userName">Username</label>
                    <input id="userName" name="userName" type="text" class="form-control"   value="<?php echo e($admindata['userName']); ?>"   placeholder="Enter userName" readonly="">
                  </div>
                  <div class="form-group">
                    <label for="full_name">Fullname</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Full Name"  value="<?php echo e($admindata['full_name']); ?>" readonly="">
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email"  value="<?php echo e($admindata['email']); ?>" readonly="" >
                  </div>
                  
                   
                  <div class="form-group">
                    <label for="password"> New Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter newPassword" >
                  </div>
                  <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="confirmPassword"  >
                  </div> 
                  
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
</div>
<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Newsblog\newsapp\resources\views/admin/Aedit.blade.php ENDPATH**/ ?>