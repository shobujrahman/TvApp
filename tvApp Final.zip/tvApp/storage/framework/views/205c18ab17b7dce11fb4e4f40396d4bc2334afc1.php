
<?php $__env->startSection('content'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Slider</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Manage Slider</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
 <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Manage Slider</h3>
              <a href="<?php echo e(url('admin/slidecreate')); ?>"
                style="max-width: 150px; float:right; display:inline-block;" 
                class="btn btn-block btn-success">Add Slider</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
            
              <table id="story" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Sl.No</th>
                    <th>Name</th>
                    <th>Story Item</th>
                    <!-- <th>Image</th> -->
                    <th>Action</th>
                  </tr>
                </thead>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <!-- <th><?php echo e($slider->id); ?></th> -->
                    <td><?php echo e($no++); ?></td>
                    <th><?php echo e($slider->name); ?></th>
                    <th> <?php echo e($slider->story_title); ?></th>
                    <td>
                    
                    <a href="<?php echo e(url('admin/slideedit/'.$slider->id)); ?>"><i class="material-icons option-icon">mode_edit</i></a>
                    &nbsp; &nbsp;
                    <a href="<?php echo e(url('admin/Sshow/')); ?>"><i class="material-icons option-icon">launch</i></a>
                    &nbsp; &nbsp;
                    <a href="<?php echo e(url('admin/slidedelete/'.$slider->id)); ?>" onclick="return confirm('Are you sure want to delete this Slider?')" ><i class="material-icons option-icon">delete</i></a>
                  </td>
                  </tr>
                
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Story\storyadmin\resources\views/admin/slider.blade.php ENDPATH**/ ?>