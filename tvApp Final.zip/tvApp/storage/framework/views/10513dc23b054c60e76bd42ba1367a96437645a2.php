
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Notifications</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/notifications')); ?>">Notifications</a></li>
                        <li class="breadcrumb-item active">Send Notifications</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Send Notifications</h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                                class="fas fa-remove"></i></button>
                    </div>
                </div>


                <div style="text-align: center;">

                  <h4>Laravel 8 Firebase Web Push Notification Tutorial</h4>

                  <button id="btn-nft-enable" onclick="initFirebaseMessagingRegistration()"
                      class="btn btn-danger btn-xs btn-flat">Click here - Allow Notification</button>
              </div>
                <!-- /.card-header onsubmit="return validateform()"-->
                <form name="storyForm" id="storyForm" action="<?php echo e(url('admin/notifications/send-notification/'.$prohor->id)); ?>" method="post"  
                    enctype="multipart/form-data"><?php echo csrf_field(); ?>

                    
                    <div class="card-body">
                        <!-- 1st row -->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label for="notifi_title">Title</label>
                                    <input type="text" class="form-control" name="notifi_title" id="notifi_title"  value="<?php echo e($prohor->notifi_title); ?>">
                                </div>
                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label for="message">Message</label>
                                    <input type="text" class="form-control" name="message" id="message" value="<?php echo e($prohor->message); ?>">
                                </div>

                                <!-- <div class="form-group">
                                    <label for="notifi_image">Image</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="notifi_image" name="notifi_image" >
                                    </div>

                                    <br>
                                    <div>
                                        <img style="width:180px; height:100px;"
                                            src="<?php echo e(asset('images/notification_image/'.$prohor->notifi_image)); ?>">
                                    </div>
                                </div> -->

                                <!-- <div class="form-group">
                                    <label for="link">Url</label>
                                    <input type="text" class="form-control" name="link" id="link" value="<?php echo e($prohor->link); ?>">
                                </div> -->
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Send Notification</button>
                    </div>
                </form>
            </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.23.0/firebase.js"></script>
    <script>
    var firebaseConfig = {
        apiKey: "AIzaSyB_x3W6ICiDqW5sbwNaYcHqepFy5zNpdD4",
    authDomain: "notificationfcm-7c461.firebaseapp.com",
    projectId: "notificationfcm-7c461",
    storageBucket: "notificationfcm-7c461.appspot.com",
    messagingSenderId: "672838940172",
    appId: "1:672838940172:web:11a377220f545486c2a029",
    measurementId: "G-3YN7CJWDCP"
    };

    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();

    function initFirebaseMessagingRegistration() {
        messaging
            .requestPermission()
            .then(function() {
                return messaging.getToken()
            })
            .then(function(token) {
                console.log(token);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    }
                });

                $.ajax({
                    url: '<?php echo e(url("admin/notifications/save-token")); ?>',
                    type: 'POST',
                    data: {
                        token: token
                    },
                    dataType: 'JSON',
                    success: function(response) {
                        alert('Token saved successfully.');
                    },
                    error: function(err) {
                        console.log('User Chat Token Error' + err);
                    },
                });

            }).catch(function(err) {
                console.log('User Chat Token Error' + err);
            });
    }

    messaging.onMessage(function(payload) {
        const noteTitle = payload.notification.notifi_title;
        const noteOptions = {
            body: payload.notification.message,
            icon: payload.notification.icon,
        };
        new Notification(noteTitle, noteOptions);
    });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewsApp\newsapp\newsapp\resources\views/admin/notification_show.blade.php ENDPATH**/ ?>