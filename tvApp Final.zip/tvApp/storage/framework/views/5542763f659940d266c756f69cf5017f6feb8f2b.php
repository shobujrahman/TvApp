<?php $__env->startSection('content'); ?>

<div class="container fluid">
     <div class="card" style="width: 68rem; margin-left: 3rem;">
         <div class="category-form" style="margin: 3rem 3rem;">

             <div class="category-from">
                             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <form method="post" action="<?php echo e(url('admin/notifications/send')); ?>" enctype="multipart/form-data">
                     <?php echo e(csrf_field()); ?>


                     <div class="form-group">
                         <label for="title">Title</label>
                         <input type="text" class="form-control" id="title" placeholder="Titlle" name="title"></input>
                     </div>

                     <div class="form-group">
                         <label for="formGroupExampleInput1">Message</label>
                         <textarea type="text" class="form-control" id="formGroupExampleInput1" placeholder="message" name="message"></textarea>
                     </div>

			         <div class="form-group">
                         <label for="url">url</label>
                         <input type="text" class="form-control" id="url" placeholder="https://www.google.com/" name="url"></input>
                     </div>

                     <div class="form-group">
                         <label for="imageURl">Image Url</label>
                         <input type="text" class="form-control" id="imageURl" placeholder=" https://xxxxxxxx.jpg/png/" name="image_url"></input>
                     </div>


                     <div class="form-group float-right">
                         <button type="submit" class="btn btn-info">send notification</button>
                     </div>

                 </form>
             </div>
         </div>
     </div>
 </div>

<?php $__env->stopSection(); ?>

    

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Newsblog\newsapp\resources\views/admin/notification.blade.php ENDPATH**/ ?>