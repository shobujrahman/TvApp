<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Slider</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Manage Slider</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-12">
                 <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Manage Slider</h3>
                        <a href="<?php echo e(url('admin/slidecreate')); ?>"
                            style="max-width: 150px; float:right; display:inline-block;"
                            class="btn btn-block btn-success">Add Slider</a>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <table id="story" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Sl.No</th>
                                    <th>Name</th>
                                    <th>News Item</th>
                                    <th>Image</th>
                                    <th style="width:180px;">Action</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($slider->name); ?></td>
                                <td> <?php echo e($slider->story_title); ?></td>
                                <td>
                                    <?php if(!empty($slider->story_image)): ?>
                                    <img style="width: 50px; height: 50px;"
                                        src="<?php echo e(asset('images/story_images/'.$slider->story_image)); ?>" />
                                    <?php endif; ?>
                                </td>
                                <td>

                                    <a href="<?php echo e(url('admin/slideedit/'.$slider->id)); ?>" class="btn btn-success"
                                        role="button"><i class="material-icons option-icon">mode_edit</i></a>
                                    &nbsp; &nbsp;
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModalCenter_<?php echo e($slider->id); ?>">
                                        <i class="material-icons option-icon">launch</i>
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModalCenter_<?php echo e($slider->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLongTitle">Sliders</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <br>
                                                    <h3>Name:- </h3>
                                                    <h5><?php echo e($slider->name); ?></h5>
                                                    <br>
                                                    <br>
                                                    <h3>News Item:- </h3>
                                                    <h5><?php echo e($slider->story_title); ?></h5>
                                                    <br>
                                                    <br>
                                                    <h3>Image:- </h3>
                                                        <?php if(!empty($slider->story_image)): ?>
                                                        <img style="width: 100px; height: 100px;"
                                                            src="<?php echo e(asset('images/story_images/'.$slider->story_image)); ?>" />
                                                        <?php endif; ?>
                                                    <br>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary"
                                                        data-dismiss="modal">Close</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    &nbsp; &nbsp;
                                    <a href="<?php echo e(url('admin/slidedelete/'.$slider->id)); ?>" class="btn btn-danger"
                                        role="button"
                                        onclick="return confirm('Are you sure want to delete this Slider?')"><i
                                            class="material-icons option-icon">delete</i></a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewsApp1\newsapp\resources\views/admin/slider.blade.php ENDPATH**/ ?>