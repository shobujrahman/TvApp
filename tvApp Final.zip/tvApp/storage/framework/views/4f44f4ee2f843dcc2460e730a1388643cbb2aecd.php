<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Add Content</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/content')); ?>">Content</a></li>
            <li class="breadcrumb-item active">Add Content</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
    <!-- /.content-header -->
      <!-- Main content -->
      <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add New Content</h3>
              </div>
              <br>
               <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
              <!-- /.card-header -->
              <!-- form start -->
              <form name="contentForm" id="contentForm"  action="<?php echo e(url('admin/content-submit')); ?>"   method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="prdct_name">product Name</label>
                    <input type="text" class="form-control" id="prdct_name" name="prdct_name" value="<?php echo e(old('prdct_name')); ?>" placeholder="Enter Product Name" >
                  </div>
                  <div class="form-group">
                    <label for="prdct_price">product Price</label>
                    <input type="text" class="form-control" id="prdct_price" name="prdct_price" value="<?php echo e(old('prdct_price')); ?>" placeholder="Enter Product Price" >
                  </div>
                  <div class="form-group">
                    <label for="prdct_key">product Key</label>
                    <input type="text" class="form-control" id="prdct_key" name="prdct_key" value="<?php echo e(old('prdct_key')); ?>" placeholder="Enter Product Key" >
                  </div>
                  
                </div>
                <!-- /.card-body -->
                

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
</div>
<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ServerProject\Tv_app\tvApp\resources\views/admin/content_create.blade.php ENDPATH**/ ?>