<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!--  -->
                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">

                            <h3>
                                <?php echo e($chnlCount); ?>

                            </h3>


                            <p>Manage News</p>
                        </div>
                        <div class="icon">
                            <i class="small material-icons">auto_stories</i>
                        </div>
                        <a href="<?php echo e(url('admin/Nindex')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!--  -->
                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo e($tvCatCount); ?></h3>

                            <p>Manage Category</p>
                        </div>
                        <div class="icon">
                            <i class="small material-icons">view_list</i>
                        </div>
                        <a href="<?php echo e(url('admin/manageCategory')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-light">
                        <div class="inner">
                            <h3><?php echo e($notifiCount); ?></h3>

                            <p>Notifications</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-bell"></i>
                        </div>
                        <a href="<?php echo e(url('admin/notifications')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-secondary">
                        <div class="inner">
                            <h3><?php echo e($sliderCount); ?></h3>

                            <p>Slider</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-film"></i>
                        </div>
                        <a href="<?php echo e(url('admin/slider')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3> <?php echo e($aCount); ?> </h3>

                            <p>Administrator</p>
                        </div>
                        <div class="icon">
                            <i class="small material-icons">people</i>
                        </div>
                        <a href="<?php echo e(url('admin/Aindex')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-dark">
                        <div class="inner">
                            <h3><?php echo e($adCount); ?></h3>

                            <p>Advertisement</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-ad"></i>
                        </div>
                        <a href="<?php echo e(url('admin/advertisement')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!--  -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3>1</h3>

                            <p>Settings</p>
                        </div>
                        <div class="icon">
                            <i class="small material-icons">settings</i>
                        </div>
                        <a href="<?php echo e(url('admin/settings')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!--  -->
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tv_app\tvApp\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>