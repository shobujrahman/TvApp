
<?php $__env->startSection('content'); ?>

<?php
$videotypes = DB::table('videotypes')->get();
?>



<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Notifications</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/notifications')); ?>">Notifications</a></li>
                        <li class="breadcrumb-item active">Add Notifications</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Add Notifications</h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                                class="fas fa-remove"></i></button>
                    </div>
                </div>
                <!-- /.card-header onsubmit="return validateform()"-->
                <form name="storyForm" id="storyForm" action="<?php echo e(url('admin/notifications/update/'.$notifiEdit->id)); ?>" method="post"  
                    enctype="multipart/form-data"><?php echo csrf_field(); ?>

                    <input type="hidden" name="old_image" value="<?php echo e($notifiEdit->notifi_image); ?>">
                    <div class="card-body">
                        <!-- 1st row -->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label for="notifi_title">Title</label>
                                    <input type="text" class="form-control" name="notifi_title" id="notifi_title"  value="<?php echo e($notifiEdit->notifi_title); ?>">
                                </div>
                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label for="message">Message</label>
                                    <input type="text" class="form-control" name="message" id="message" value="<?php echo e($notifiEdit->message); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="notifi_image">Image</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="notifi_image" name="notifi_image" >
                                    </div>

                                    <br>
                                    <div>
                                        <img style="width:180px; height:100px;"
                                            src="<?php echo e(asset('images/notification_image/'.$notifiEdit->notifi_image)); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="link">Url</label>
                                    <input type="text" class="form-control" name="link" id="link" value="<?php echo e($notifiEdit->link); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Publish</button>
                    </div>
                </form>
            </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewsApp\newsapp\newsapp\resources\views/admin/notification_edit.blade.php ENDPATH**/ ?>