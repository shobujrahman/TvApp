
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Stories</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Administrator</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">

         <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Administrator</h3>
              <a href="<?php echo e(url('admin/Acreate')); ?>"
                style="max-width: 150px; float:right; display:inline-block;" 
                class="btn btn-block btn-success">Add New Admin</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">

            <form class="form-inline my-2 my-lg-0 d-flex justify-content-end" action="<?php echo e(url('admin/Aindex/search')); ?>" ><?php echo csrf_field(); ?>
                <input class="form-control mr-sm-2" type="search" name="name" placeholder="Search Keyword" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
              </form>
    <br>
              <table id="administrator" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>id</th>
                    <th>Username</th>
                    <th>Fullname</th>
                    <th>Email</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($admin->id); ?></td>
                          <td><?php echo e($admin->userName); ?></td>
                          <td><?php echo e($admin->full_name); ?></td>
                          <td><?php echo e($admin->email); ?></td>
                          <td>
                            <a href="<?php echo e(url('admin/Aedit/'.$admin->id)); ?>"><i class="material-icons option-icon">mode_edit</i></a>
                            &nbsp; &nbsp;
                            <?php
                              if ($admin->id == 1) {

                                } else {
                            ?>
                                                    
                              <a href="<?php echo e(url('admin/Adelete/'.$admin->id)); ?>"onclick="return confirm('Are you sure want to delete this SubAdmin?')" ><i class="material-icons option-icon">delete</i></a>
                                <?php
                                }
                            ?>
                            
                          </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <br>
              <div>
                <?php echo e($admins->links()); ?>

              </div>
                </tbody>

              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Story\storyadmin\resources\views/admin/Aindex.blade.php ENDPATH**/ ?>