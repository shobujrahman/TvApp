
<?php $__env->startSection('content'); ?>
  
<?php 
    $categories = DB::table('categories')->get();
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Story</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/Sindex')); ?>">Manage Story</a></li>
              <li class="breadcrumb-item active">Edit Story</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Edit Story</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <form name="storyForm" id="storyForm" action="<?php echo e(url('admin/Supdate/'.$storyEdit->id)); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <input type="hidden" name="old_image" value ="<?php echo e($storyEdit->story_image); ?>">
                <input type="hidden" name="old_vdo" value ="<?php echo e($storyEdit->video_id); ?>">
                <div class="card-body">
                    <!-- 1st row -->
                    <div class="row">
                        <div class="col-md-6">


                            <div class="form-group">
                                <label for="story_title">Story Title</label>
                                <input type="text" class="form-control" name="story_title" id="story_title" value="<?php echo e($storyEdit->story_title); ?>" >
                            </div>
                            
                            <!-- /.form-group -->
                            <div class="form-group">
                                <label> Category</label>
                                <select name="cat_name" id="cat_name" class="form-control select2" style="width: 100%;">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($category->id); ?>"<?php if($category->id==$storyEdit->cat_id){
                                        echo "selected";
                                    } ?>><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- /.form-group -->


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Content Type</label>
                                    <select  class="form-control show-tick"  name="upload_type" id="upload_type">
                                                    
                                            <!-- <option value=" ">Choose Options--</option> -->
                                            <option <?php if($storyEdit->content_type == 'stp'){echo 'selected';} ?> value="stp" >Standard Post</option>
                                            <option <?php if($storyEdit->content_type == 'ytb'){echo 'selected';} ?> value="ytb" >Video Post (YouTube)</option>
                                            <option <?php if($storyEdit->content_type == 'vurl'){echo 'selected';} ?> value="vurl" >Video Post (Url)</option>
                                    </select>
                                </div>
                            </div>
                            <!--  -->
                            <div id=standard_post style="display:none;"  class="form-group">
                                <label for="image"> Image*</label>
                                 <div class="input-group">
                                    <input type="file" class="form-control" id="image" name="image" >
                                </div>

                                <br>
                                <div>
                                    <img style="width:150px; height:75px;" src="<?php echo e(asset('images/story_images/'.$storyEdit->story_image)); ?>">
                                </div>
                            </div> 
                            <!--  -->
                            <div id=you_tube  style="display:none;" class="form-group">
                                <label for="you_vido"> Video </label>
                                <div class="input-group">
                                     <input type="file"  class="form-control"  id="you_vido" name="you_vido" >
                                </div>
                                <br>
                                <div>
                                    <video >
                                        <source src="<?php echo e(asset('images/story_images/videos/'.$storyEdit->video_id)); ?>" type="video/mp4">
                                    </video>
                                </div>

                                <div  class="form-group">
                                    <label for="story_image"> Video Image</label>
                                    <div class="input-group">
                                        <input type="file"  class="form-control" id="story_image" name="story_image">
                                    </div>
                                    <br>
                                    <div>
                                        <img style="width:150px; height:75px;" src="<?php echo e(asset('images/story_images/'.$storyEdit->story_image)); ?>">
                                    </div>
                                </div> 
                            </div>
                             <!--  -->
                            <div id=video_url  style="display:none;" class="form-group">
                                <label for="you_url">Youtube URL</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="text"  class="form-control" id="you_url" name="you_url" placeholder="https://www.youtube.com/watch?v=33F5DJw3aiU" value="<?php echo e($storyEdit->video_url); ?>">
                                    </div>
                                </div>

                                <div  class="form-group">
                                    <label for="url_image"> Url Image</label>
                                    <div class="input-group">
                                        <input type="file"  class="form-control" id="url_image" name="url_image">
                                    </div>
                                    <br>
                                    <div>
                                        <img style="width:150px; height:75px;" src="<?php echo e(asset('images/story_images/'.$storyEdit->story_image)); ?>">
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <!-- end 1strow -->

                
                    <!-- description -->
                        <div class="form-group">
                            <label for="description">
                                Story Description
                            </label>
                            <textarea class="form-control" value="" name="description" id="description" class="form-control" cols="60" rows="10" >
                                            <?php echo e($storyEdit->story_description); ?>

                            </textarea>
                            <script>
                                CKEDITOR.replace( 'description' );
                            </script>                             
                        </div>
                    <!-- end Description -->
                </div>
                <!-- end cardbody -->
                <!-- button -->
                <div class="card-footer">
                    <button type="submit"  class="btn btn-primary">Publish</button>
                </div>
                <!-- end button -->
            </form>

        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Newstoryadmin\storyadmin\resources\views/admin/Sedit.blade.php ENDPATH**/ ?>