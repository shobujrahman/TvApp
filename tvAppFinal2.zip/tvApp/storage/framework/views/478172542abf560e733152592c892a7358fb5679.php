
<?php $__env->startSection('content'); ?>

<?php
$newses = DB::table('news')->get();
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Slider</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/slider')); ?>">Manage Slider</a></li>
                        <li class="breadcrumb-item active">Edit Slider</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Edit Slider</h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                                class="fas fa-remove"></i></button>
                    </div>
                </div>
                <!-- /.card-header -->
                <form name="sliderForm" id="sliderForm" action="<?php echo e(url('admin/slideupdate/'.$slideEdit->id)); ?>"
                    method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <input type="hidden" name="old_image" value="<?php echo e($slideEdit->story_image); ?>">
                    <div class="card-body">
                        <!-- 1st row -->
                        <div class="row">
                            <div class="col-md-6">


                                <div class="form-group">
                                    <label for="name">Slider Name</label>
                                    <input type="text" class="form-control" name="name" id="name"
                                        value="<?php echo e($slideEdit->name); ?>" placeholder="Enter Name">
                                </div>

                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label> News Item</label>
                                    <select name="story_id" id="story_id" class="form-control select2"
                                        style="width: 100%;">
                                        <option>Select</option>
                                        <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($news->id); ?>" <?php if($news->id==$slideEdit->story_id){
                                        echo "selected";
                                    } ?>><?php echo e($news->story_title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <!--  -->
                                <div class="form-group">
                                    <label for="story_image">Story Image</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="story_image" name="story_image"
                                            placeholder="Enter Thumbnail Url">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Publish</button>
                    </div>

                </form>

            </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewsApp\newsapp\resources\views/admin/slideedit.blade.php ENDPATH**/ ?>