
<?php $__env->startSection('content'); ?>

<?php
$videotypes = DB::table('videotypes')->get();
?>



<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>News</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/Nindex')); ?>">Manage News</a></li>
                        <li class="breadcrumb-item active">Add News</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Add News</h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                                class="fas fa-remove"></i></button>
                    </div>
                </div>
                <!-- /.card-header onsubmit="return validateform()"-->
                <form name="storyForm" id="storyForm" action="<?php echo e(url('admin/Nsubmit')); ?>" method="post"  
                    enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <div class="card-body">
                        <!-- 1st row -->
                        <div class="row">
                            <div class="col-md-6">


                                <div class="form-group">
                                    <label for="story_title">News Title</label>
                                    <input type="text" class="form-control" name="story_title" id="story_title"
                                         value="<?php echo e(old('story_title')); ?>" placeholder="Enter News Title">
                                </div>

                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label> Category</label>
                                    <select name="cat_name" id="cat_name" class="form-control select2"
                                        style="width: 100%;">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label for="story_image">Thumbnail Image</label>
                                    <div class="input-group">
                                        <div class="input-group">
                                            <input type="file" class="form-control" id="story_image" name="story_image" value="<?php echo e(old('story_image')); ?>">
                                        </div>
                                    </div>
                                </div>

                                <br>
                                <label>Type</label>
                                <select id="type" name="type_name" class="form-control select2" >
                                    <option value="">Choose Video Type</option>
                                    <?php $__currentLoopData = $videotypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <br>
                                <br>
                                
                                <div class="form-group"  style="display: none;"  id='url'>
                                    <label for="video_url">Video Url</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="video_url" name="video_url"
                                            value="<?php echo e(old('video_url')); ?>"
                                            placeholder=" https://www.youtube.com/watch?v=II2EO3">
                                    </div>
                                </div>

                                <div class="form-group" style="display: none;" id="upload_video">
                                    <label for="video_upload">Video Upload</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="video_upload" name="video_upload" >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- description -->
                        <br>

                        <div class="form-group">
                            <label for="story_description">
                                News Description
                            </label>
                            <textarea class="textarea" placeholder="Place some text here" name="story_description" 
                                required
                                style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                                <?php echo e(Request::old('story_description')); ?>

                        </textarea>
                        </div>
                        <!-- /.description -->
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Publish</button>
                    </div>
                </form>
            </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<!-- <script type="text/javascript">

function validateform(){  
var name=document.getElementById("cat_name").value;  
  
if (name==null || name==""){  
  alert("Category can't be blank");  
  return false;  
}
 else{
    return true;
}  
}  



</script> -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewsApp\newsapp\resources\views/admin/Ncreate.blade.php ENDPATH**/ ?>