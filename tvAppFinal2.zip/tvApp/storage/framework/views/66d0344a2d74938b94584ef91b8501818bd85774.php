
<?php $__env->startSection('content'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Settings</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Settings</li>
            </ol>
          </div>
        </div>
      </div>
      <!-- /.container-fluid -->
    </section>

    
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Settings</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <form name="storyForm" id="storyForm" action="<?php echo e(url('admin/settings/update')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?> 
                <div class="card-body">
                    <!-- 1st row -->
                    <div class="row">
                      <!-- Admob Ads -->                     
                      <div class="col-md-12">
                          <!-- <br> -->
                        <label class="card-title">Admob Ads:</label>
                      </div>
                          <!-- <br> -->
                          <br>
                      <div class="col-md-6">
                        <div class="form-group">
                            <h6>Inter Ad Unit</h6>
                            <input type="text" class="form-control" name="admob_inter" id="admob_inter" value="<?php echo e($setting->admob_inter); ?>" placeholder="Inter Ad Unit" >
                        </div>
                        <div class="form-group">
                            <h6>Banner Ad Unit</h6>
                            <input type="text" class="form-control" name="admob_banner" id="admob_banner" value="<?php echo e($setting->admob_banner); ?>" placeholder="Banner Ad Unit" >
                        </div>
                      </div>
                      
                      <div class="col-md-6">
                        <div class="form-group">
                            <h6>Native Ad Unit</h6>
                            <input type="text" class="form-control" name="admob_native" id="admob_native" value="<?php echo e($setting->admob_native); ?>" placeholder="Native Ad Unit" >
                        </div>
                        <div class="form-group">
                            <h6>Reward Ad Unit</h6>
                            <input type="text" class="form-control" name="admob_reward" id="admob_reward" value="<?php echo e($setting->admob_reward); ?>" placeholder="Reward Ad Unit" >
                        </div>
                      </div>

                      <!-- Admob Ads end -->
                      <!-- facebook Ads -->
                      <div class="col-md-12">
                          <br>
                        <label class="card-title">Facebook Ads:</label>
                      </div>
                          <br>
                          <br>
                      <div class="col-md-6">
                        <div class="form-group">
                            <h6>Inter Ad Unit</h6>
                            <input type="text" class="form-control" name="fb_inter" id="fb_inter" value="<?php echo e($setting->fb_inter); ?>" placeholder="Inter Ad Unit" >
                        </div>
                        <div class="form-group">
                            <h6>Banner Ad Unit</h6>
                            <input type="text" class="form-control" name="fb_banner" id="fb_banner" value="<?php echo e($setting->fb_banner); ?>" placeholder="Banner Ad Unit" >
                        </div>
                      </div>
                      
                      <div class="col-md-6">
                        <div class="form-group">
                            <h6>Native Ad Unit</h6>
                            <input type="text" class="form-control" name="fb_native" id="fb_native" value="<?php echo e($setting->fb_native); ?>" placeholder="Native Ad Unit" >
                        </div>
                        <div class="form-group">
                            <h6>Reward Ad Unit</h6>
                            <input type="text" class="form-control" name="fb_reward" id="fb_reward" value="<?php echo e($setting->fb_reward); ?>" placeholder="Reward Ad Unit" >
                        </div>
                      </div>
                      <!-- facebook Ads end -->
                      <!-- Startup Ads  -->
                      <div class="col-md-12">
                          <br>
                        <label class="card-title">Startup Ads:</label>
                      </div>
                          <br>
                          <br>
                      <div class="col-md-12">
                        <div class="form-group">
                            <h6>Inter Ad Unit</h6>
                            <input type="text" class="form-control" name="startup_inter" id="startup_inter" value="<?php echo e($setting->startup_inter); ?>" placeholder="Inter Ad Unit" >
                        </div>
                        <div class="form-group">
                            <h6>Banner Ad Unit</h6>
                            <input type="text" class="form-control" name="startup_banner" id="startup_banner" value="<?php echo e($setting->startup_banner); ?>" placeholder="Banner Ad Unit" >
                        </div>
                      </div>
                      <!-- Startup Ads end -->
                      
                      <div class="col-md-12">
                          <br>
                        <div class="form-group">
                            <label for="ads_type">Ads Type</label>
                            
                            <select name="ads_type" id="ads_type" class="form-control select2" style="width: 100%;">
                              <option selected>Select</option>
                              <option  value="0" <?php if($setting['ad_types'] == "0"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Admob</option>  
                              <option  value="1" <?php if($setting['ad_types'] == "1"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Facebook</option>  
                              <option  value="2" <?php if($setting['ad_types'] == "2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Startup</option>  
                              <option  value="3" <?php if($setting['ad_types'] == "3"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Both</option>  
                            </select>
                        </div>
                      </div>
                  
                    </div>
                  </div>
                       
                  <div class="card-footer">
                    <button type="submit"  class="btn btn-primary">update</button>
                  </div>
                    
            </form>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Story\storyadmin\resources\views/admin/admin_settings.blade.php ENDPATH**/ ?>