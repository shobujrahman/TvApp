
<?php $__env->startSection('content'); ?>

<?php
$categories = DB::table('categories')->get();
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>News</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/Sindex')); ?>">Manage News</a></li>
                        <li class="breadcrumb-item active">Edit News</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Edit News</h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                                class="fas fa-remove"></i></button>
                    </div>
                </div>
                <!-- /.card-header -->
                <form name="storyForm" id="storyForm" action="<?php echo e(url('admin/Supdate/'.$newsEdit->id)); ?>" method="post"
                    enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <input type="hidden" name="old_image" value="<?php echo e($newsEdit->story_image); ?>">
                    <input type="hidden" name="old_video" value="<?php echo e($newsEdit->video_upload); ?>">

                    <div class="card-body">
                        <!-- 1st row -->
                        <div class="row">
                            <div class="col-md-6">


                                <div class="form-group">
                                    <label for="story_title">News Title</label>
                                    <input type="text" class="form-control" name="story_title" id="story_title"
                                        value="<?php echo e($newsEdit->story_title); ?>">
                                </div>

                                <!-- /.form-group -->
                                <div class="form-group">
                                    <label> Category</label>
                                    <select name="cat_name" id="cat_name" class="form-control select2"
                                        style="width: 100%;">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if($category->id==$newsEdit->cat_id){
                                        echo "selected";
                                    } ?>><?php echo e($category->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="story_image">Thumbnail Image</label>
                                    <div class="input-group">
                                        <div class="input-group">
                                            <input type="file" class="form-control" id="story_image" name="story_image">
                                        </div>
                                    </div>
                                    <br>
                                    <div>
                                        <img style="width:180px; height:100px;"
                                            src="<?php echo e(asset('images/story_images/'.$newsEdit->story_image)); ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="video_url">Video Url</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="video_url" name="video_url"
                                            value="<?php echo e($newsEdit->video_url); ?>" placeholder="Enter URL">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="video_upload">Video Upload</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="video_upload" name="video_upload">
                                    </div>
                                    <br>
                                    <div>
                                        <video width="320" height="220" preload="metadata" controls>
                                            <source src="<?php echo e(asset('images/story_images/'.$newsEdit->video_upload)); ?>"
                                                type="video/mp4">
                                        </video>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- end 1strow -->


                        <!-- description -->
                        <div class="form-group">
                            <label for="story_description">
                                News Description
                            </label>
                            <textarea class="textarea" placeholder="Place some text here" name="story_description"
                                style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                                <?php echo e($newsEdit->story_description); ?>

                            </textarea>
                        </div>
                        <!-- end Description -->
                    </div>
                    <!-- end cardbody -->
                    <!-- button -->
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                    <!-- end button -->
                </form>

            </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewsApp\newsapp\resources\views/admin/Sedit.blade.php ENDPATH**/ ?>