
<?php $__env->startSection('content'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Stories</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Manage Story</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Manage Story</h3>
              <a href="<?php echo e(url('admin/addStory')); ?>"
                style="max-width: 150px; float:right; display:inline-block;" 
                class="btn btn-block btn-success">Add Story</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="category" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>id</th>
                  <th>Story Title</th>
                  <th>Story Image</th>
                  <th>Category</th>
                  <th>Type</th>
                  <th>Action</th>
                </tr>
</thead>
                <tbody>
                <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($story->id); ?></td>
                  <td><?php echo e($story->story_title); ?></td>
                  <td><?php echo e($story->story_image); ?></td>
                  <td><?php echo e($story->cat_id); ?></td>
                  <td><?php echo e($story->content_type); ?></td>
                  <td><a href="<?php echo e(url('admin/editStory/'.$story)); ?>">Edit</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
                </tbody>

              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Story_admin\storyadmin\resources\views/admin/admin_manageStory.blade.php ENDPATH**/ ?>