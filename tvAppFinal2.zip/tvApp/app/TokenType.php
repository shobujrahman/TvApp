<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TokenType extends Model
{
    protected $gaurded=[];
}
