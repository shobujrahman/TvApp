<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAgentType extends Model
{
    protected $guarded = [];
}
